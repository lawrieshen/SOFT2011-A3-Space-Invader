package invaders.observer;

public interface Observer {

    public void update();
}
