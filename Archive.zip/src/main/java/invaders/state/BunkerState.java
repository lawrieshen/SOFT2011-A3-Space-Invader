package invaders.state;

import java.io.Serializable;

public interface BunkerState extends Serializable {
    public void takeDamage();
}
