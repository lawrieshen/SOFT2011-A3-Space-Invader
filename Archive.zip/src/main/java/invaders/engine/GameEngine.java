package invaders.engine;

import java.util.ArrayList;
import java.util.List;

import invaders.ConfigReader;
import invaders.builder.BunkerBuilder;
import invaders.builder.Director;
import invaders.builder.EnemyBuilder;
import invaders.factory.EnemyProjectile;
import invaders.factory.Projectile;
import invaders.gameobject.Bunker;
import invaders.gameobject.Enemy;
import invaders.gameobject.GameObject;
import invaders.entities.Player;
import invaders.observer.GameScore;
import invaders.observer.SystemStats;
import invaders.observer.GameTime;
import invaders.rendering.Renderable;
import invaders.strategy.FastProjectileStrategy;
import invaders.strategy.SlowProjectileStrategy;
import javafx.application.Platform;
import javafx.util.Duration;
import org.json.simple.JSONObject;

/**
 * This class manages the main loop and logic of the game
 */
public class GameEngine {
	private List<GameObject> gameObjects = new ArrayList<>(); // A list of game objects that gets updated each frame
	private List<GameObject> pendingToAddGameObject = new ArrayList<>();
	private List<GameObject> pendingToRemoveGameObject = new ArrayList<>();

	private List<Renderable> pendingToAddRenderable = new ArrayList<>();
	private List<Renderable> pendingToRemoveRenderable = new ArrayList<>();

	private List<Renderable> renderables =  new ArrayList<>();

	private Player player;

	private boolean left;
	private boolean right;
	private int gameWidth;
	private int gameHeight;
	private int timer = 45;
	private GameTime gameTime = new GameTime();
	private GameScore gameScore = new GameScore();
	private SystemStats systemStats = new SystemStats(gameTime, gameScore);
	private int numberOfEnemy = 0;

	public GameEngine(String config){
		// Read the config here
		ConfigReader.parse(config);

		// Get game width and height
		gameWidth = ((Long)((JSONObject) ConfigReader.getGameInfo().get("size")).get("x")).intValue();
		gameHeight = ((Long)((JSONObject) ConfigReader.getGameInfo().get("size")).get("y")).intValue();

		//Get player info
		this.player = new Player(ConfigReader.getPlayerInfo());
		renderables.add(player);


		Director director = new Director();
		BunkerBuilder bunkerBuilder = new BunkerBuilder();
		//Get Bunkers info
		for(Object eachBunkerInfo:ConfigReader.getBunkersInfo()){
			Bunker bunker = director.constructBunker(bunkerBuilder, (JSONObject) eachBunkerInfo);
			gameObjects.add(bunker);
			renderables.add(bunker);
		}


		EnemyBuilder enemyBuilder = new EnemyBuilder();
		//Get Enemy info
		for(Object eachEnemyInfo:ConfigReader.getEnemiesInfo()){
			Enemy enemy = director.constructEnemy(this,enemyBuilder,(JSONObject)eachEnemyInfo);
			gameObjects.add(enemy);
			renderables.add(enemy);
			numberOfEnemy++;
		}
		numberOfEnemy = numberOfEnemy*2;

		/**Observer**/
		//register
		gameTime.attach(systemStats);
		gameScore.attach(systemStats);
	}

	/**
	 * Updates the game/simulation
	 */
	public void update(){
		timer+=1;

		movePlayer();

		for(GameObject go: gameObjects){
			go.update(this);
		}

		for (int i = 0; i < renderables.size(); i++) {
			Renderable renderableA = renderables.get(i);
			for (int j = i+1; j < renderables.size(); j++) {
				Renderable renderableB = renderables.get(j);

				if((renderableA.getRenderableObjectName().equals("Enemy") && renderableB.getRenderableObjectName().equals("EnemyProjectile"))
						||(renderableA.getRenderableObjectName().equals("EnemyProjectile") && renderableB.getRenderableObjectName().equals("Enemy"))||
						(renderableA.getRenderableObjectName().equals("EnemyProjectile") && renderableB.getRenderableObjectName().equals("EnemyProjectile"))||
						(renderableA.getRenderableObjectName().equals("Enemy") && renderableB.getRenderableObjectName().equals("Enemy"))){
					//do nothing
				}else{
					if(renderableA.isColliding(renderableB) && (renderableA.getHealth()>0 && renderableB.getHealth()>0)) {
						renderableA.takeDamage(1);
						renderableB.takeDamage(1);
						/**Gain Score Here**/
						if (renderableA.getHealth()<=0) {
							if (renderableA.getClass().equals(EnemyProjectile.class)) {
								if (((EnemyProjectile) renderableA).getStrategy().getClass().equals(SlowProjectileStrategy.class)) {
									gameScore.setGameScore(gameScore.getGameScore() + 1);
									gameScore.notifyObservers();
								} else if (((EnemyProjectile) renderableA).getStrategy().getClass().equals(FastProjectileStrategy.class)) {
									gameScore.setGameScore(gameScore.getGameScore() + 2);
									gameScore.notifyObservers();
								}
							} else if (renderableA.getClass().equals(Enemy.class)) {
								if (((Enemy) renderableA).getProjectileStrategy().getClass().equals(SlowProjectileStrategy.class)){
									gameScore.setGameScore(gameScore.getGameScore() + 3);
									gameScore.notifyObservers();
								} else if (((Enemy) renderableA).getProjectileStrategy().getClass().equals(FastProjectileStrategy.class)){
									gameScore.setGameScore(gameScore.getGameScore() + 4);
									gameScore.notifyObservers();
								}
							} else if (renderableA.getClass().equals(Player.class)){
								//when player is dead, end game
								System.out.println("Aliens Win");
								System.out.println("Game Score: "+gameScore.getGameScore());
								double minutes = (double) gameTime.getGameTime().toMinutes();
								double seconds = (double) (gameTime.getGameTime().toSeconds()%60);

								String formattedTime  = String.format("%02.0f:%02.0f", minutes, seconds);
								System.out.println("Game Time: "+formattedTime);
								Platform.exit();
							}
						}
					}
				}
			}
		}


		// ensure that renderable foreground objects don't go off-screen
		int offset = 1;
		for(Renderable ro: renderables){
			if(!ro.getLayer().equals(Renderable.Layer.FOREGROUND)){
				continue;
			}
			if(ro.getPosition().getX() + ro.getWidth() >= gameWidth) {
				ro.getPosition().setX((gameWidth - offset) -ro.getWidth());
			}

			if(ro.getPosition().getX() <= 0) {
				ro.getPosition().setX(offset);
			}

			if(ro.getPosition().getY() + ro.getHeight() >= gameHeight) {
				ro.getPosition().setY((gameHeight - offset) -ro.getHeight());
			}

			if(ro.getPosition().getY() <= 0) {
				ro.getPosition().setY(offset);
			}
		}

		/**record game time**/
		gameTime.setTime(gameTime.getGameTime().add(new Duration(17)));
		gameTime.notifyObservers();


		int counter = 0;
		for (Renderable ro : renderables){
			if (ro.isAlive() && ro.getRenderableObjectName().equals("Enemy")){
				counter++;
			}
		}
		if (counter <=0){
			System.out.println("Player Wins");
			System.out.println("Game Score: "+gameScore.getGameScore());
			double minutes = (double) gameTime.getGameTime().toMinutes();
			double seconds = (double) (gameTime.getGameTime().toSeconds()%60);

			String formattedTime  = String.format("%02.0f:%02.0f", minutes, seconds);
			System.out.println("Game Time: "+formattedTime);
			Platform.exit();
		}
	}

	public List<Renderable> getRenderables(){
		return renderables;
	}

	public List<GameObject> getGameObjects() {
		return gameObjects;
	}
	public List<GameObject> getPendingToAddGameObject() {
		return pendingToAddGameObject;
	}

	public List<GameObject> getPendingToRemoveGameObject() {
		return pendingToRemoveGameObject;
	}

	public List<Renderable> getPendingToAddRenderable() {
		return pendingToAddRenderable;
	}

	public List<Renderable> getPendingToRemoveRenderable() {
		return pendingToRemoveRenderable;
	}


	public void leftReleased() {
		this.left = false;
	}

	public void rightReleased(){
		this.right = false;
	}

	public void leftPressed() {
		this.left = true;
	}
	public void rightPressed(){
		this.right = true;
	}

	public boolean shootPressed(){
		if(timer>45 && player.isAlive()){
			Projectile projectile = player.shoot();
			gameObjects.add(projectile);
			renderables.add(projectile);
			timer=0;

			return true;
		}
		return false;
	}

	private void movePlayer(){
		if(left){
			player.left();
		}

		if(right){
			player.right();
		}
	}

	public int getGameWidth() {
		return gameWidth;
	}

	public int getGameHeight() {
		return gameHeight;
	}

	public Player getPlayer() {
		return player;
	}

	public SystemStats getSystemStats(){return systemStats;}
	public GameScore getGameScore(){return gameScore;}
	public GameTime getGameTime(){return  gameTime;}

	public int getNumberOfEnemy(){return numberOfEnemy;}
	public void setNumberOfEnemy(int count){this.numberOfEnemy = count;}
}
