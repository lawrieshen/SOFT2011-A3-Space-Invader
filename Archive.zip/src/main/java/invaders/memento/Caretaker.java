package invaders.memento;

import invaders.gameobject.GameObject;

public interface Caretaker {
}
